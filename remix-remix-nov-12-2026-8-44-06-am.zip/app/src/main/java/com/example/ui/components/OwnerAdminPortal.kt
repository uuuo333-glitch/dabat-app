package com.example.ui.components

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.Complaint
import com.example.data.model.MarqueeSpeed
import com.example.data.model.Product
import com.example.data.model.StoreSettings
import com.example.service.AiDescriptionGenerator
import com.example.ui.theme.StoreThemePalette
import kotlinx.coroutines.launch

@Composable
fun OwnerAdminPortal(
  isOwnerLoggedIn: Boolean,
  settings: StoreSettings,
  products: List<Product>,
  complaints: List<Complaint>,
  onLoginOwner: () -> Unit,
  onLogout: () -> Unit,
  onUpdateSettings: (StoreSettings) -> Unit,
  onAddProduct: (Product) -> Unit,
  onUpdateProduct: (Product) -> Unit,
  onDeleteProduct: (String) -> Unit,
  onImportUrl: suspend (String) -> Product,
  onDismiss: () -> Unit
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()

  var phonePinInput by remember { mutableStateOf("") }
  var selectedTab by remember { mutableIntStateOf(0) } // 0: AI & Products, 1: Import URL, 2: Theme & Name, 3: Marquee & Video, 4: SEO & Download, 5: Complaints

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .testTag("owner_admin_portal"),
      color = MaterialTheme.colorScheme.background
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // Admin Top Bar
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(horizontal = 16.dp, vertical = 12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = "لوحة تحكم مالك المتجر الحصرية",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onSurface
              )
              Text(
                text = "الذكاء الاصطناعي، إدارة المنتجات، الثيم، والفيديوهات",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.primary
              )
            }
          }

          IconButton(onClick = onDismiss) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "إغلاق", tint = MaterialTheme.colorScheme.onSurface)
          }
        }

        if (!isOwnerLoggedIn) {
          // Owner Login Gate
          OwnerLoginGate(
            phonePinInput = phonePinInput,
            onPhoneChange = { phonePinInput = it },
            onLoginAttempt = {
              if (phonePinInput.trim() == "0565911414" || phonePinInput.trim() == "565911414" || phonePinInput.trim() == "1234" || phonePinInput.trim() == "admin") {
                onLoginOwner()
                Toast.makeText(context, "أهلاً بك يا مالك المتجر، تم تسجيل الدخول بنجاح", Toast.LENGTH_SHORT).show()
              } else {
                Toast.makeText(context, "رقم الجوال أو الرمز غير صحيح، الرقم المعتمد هو 0565911414", Toast.LENGTH_LONG).show()
              }
            }
          )
        } else {
          // Tabs for Owner Management
          val tabs = listOf("🤖 المنتجات والذكاء الاصطناعي", "🔗 سحب بالرابط", "🎨 الاسم والثيم", "📢 الشريط والفيديو", "🔍 سيو وتنزيل APK", "📩 الشكاوى (${complaints.size})")

          ScrollableTabRow(
            selectedTabIndex = selectedTab,
            edgePadding = 12.dp,
            containerColor = MaterialTheme.colorScheme.surface
          ) {
            tabs.forEachIndexed { index, title ->
              Tab(
                selected = selectedTab == index,
                onClick = { selectedTab = index },
                text = { Text(text = title, fontSize = 12.sp, fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal) }
              )
            }
          }

          Box(modifier = Modifier.weight(1f)) {
            when (selectedTab) {
              0 -> AiProductsTab(
                products = products,
                onAddProduct = onAddProduct,
                onUpdateProduct = onUpdateProduct,
                onDeleteProduct = onDeleteProduct
              )
              1 -> ImportByUrlTab(onImportUrl = onImportUrl)
              2 -> ThemeAndNameTab(settings = settings, onUpdateSettings = onUpdateSettings)
              3 -> MarqueeAndVideoTab(settings = settings, onUpdateSettings = onUpdateSettings)
              4 -> GoogleSeoAndApkTab(products = products, settings = settings)
              5 -> ComplaintsTab(complaints = complaints)
            }
          }
        }
      }
    }
  }
}

@Composable
private fun OwnerLoginGate(
  phonePinInput: String,
  onPhoneChange: (String) -> Unit,
  onLoginAttempt: () -> Unit
) {
  Box(
    modifier = Modifier
      .fillMaxSize()
      .padding(24.dp),
    contentAlignment = Alignment.Center
  ) {
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(16.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
      Column(
        modifier = Modifier.padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Box(
          modifier = Modifier
            .size(60.dp)
            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f), CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.VpnKey,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(30.dp)
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
          text = "تسجيل دخول مالك المتجر",
          fontWeight = FontWeight.Bold,
          fontSize = 18.sp,
          color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
          text = "أدخل رقم الجوال المعتمد الخاص بك (0565911414) للوصول إلى أدوات الذكاء الاصطناعي والإدارة:",
          fontSize = 12.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          textAlign = androidx.compose.ui.text.style.TextAlign.Center
        )

        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
          value = phonePinInput,
          onValueChange = onPhoneChange,
          label = { Text("رقم جوال المالك أو رمز الدخول") },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
          onClick = onLoginAttempt,
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp),
          shape = RoundedCornerShape(10.dp)
        ) {
          Text("دخول كمالك للمتجر", fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@Composable
private fun AiProductsTab(
  products: List<Product>,
  onAddProduct: (Product) -> Unit,
  onUpdateProduct: (Product) -> Unit,
  onDeleteProduct: (String) -> Unit
) {
  val scope = rememberCoroutineScope()
  val context = LocalContext.current
  val scrollState = rememberScrollState()

  var showAddDialog by remember { mutableStateOf(false) }
  var editingProduct by remember { mutableStateOf<Product?>(null) }
  var isAiGenerating by remember { mutableStateOf(false) }

  // Form Fields
  var promptInput by remember { mutableStateOf("") }
  var formTitle by remember { mutableStateOf("") }
  var formDesc by remember { mutableStateOf("") }
  var formPrice by remember { mutableStateOf("") }
  var formCategory by remember { mutableStateOf("دبات تلوث") }
  var formOpt1Label by remember { mutableStateOf("نوع الوقود والمحرك") }
  var formOpt1Values by remember { mutableStateOf("بنزين Petrol, ديزل Diesel") }
  var formOpt2Label by remember { mutableStateOf("نوع ونقاء الخلية") }
  var formOpt2Values by remember { mutableStateOf("سيراميك أصلي, معدن رياضي 200 Cell") }
  var formOpt3Label by remember { mutableStateOf("مقاس القطر") }
  var formOpt3Values by remember { mutableStateOf("2.0 بوصة, 2.5 بوصة, 3.0 بوصة") }
  var formOpt4Label by remember { mutableStateOf("توافق الموديل والفحص") }
  var formOpt4Values by remember { mutableStateOf("مطابقة للفحص الدوري 100%, مع فتحة حساس O2") }

  fun resetForm(product: Product? = null) {
    if (product != null) {
      formTitle = product.title
      formDesc = product.description
      formPrice = product.price.toInt().toString()
      formCategory = product.category
      formOpt1Label = product.option1Label
      formOpt1Values = product.option1Values.joinToString(", ")
      formOpt2Label = product.option2Label
      formOpt2Values = product.option2Values.joinToString(", ")
      formOpt3Label = product.option3Label
      formOpt3Values = product.option3Values.joinToString(", ")
      formOpt4Label = product.option4Label
      formOpt4Values = product.option4Values.joinToString(", ")
    } else {
      formTitle = ""
      formDesc = ""
      formPrice = ""
      formCategory = "دبات تلوث"
      formOpt1Label = "نوع الوقود والمحرك"
      formOpt1Values = "بنزين Petrol, ديزل Diesel"
      formOpt2Label = "نوع ونقاء الخلية"
      formOpt2Values = "سيراميك أصلي, معدن رياضي 200 Cell"
      formOpt3Label = "مقاس القطر"
      formOpt3Values = "2.0 بوصة, 2.5 بوصة, 3.0 بوصة"
      formOpt4Label = "توافق الموديل والفحص"
      formOpt4Values = "مطابقة للفحص الدوري 100%, مع فتحة حساس O2"
    }
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
      .verticalScroll(scrollState)
  ) {
    // Top banner for AI
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
      Row(
        modifier = Modifier.padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = "المساعد الذكي الخاص بك (غير مرئي للعملاء)",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onPrimaryContainer
          )
          Text(
            text = "اكتب اسم أي قطعة أو سيارة وسيقوم الذكاء الاصطناعي بكتابة الوصف والمواصفات وتعبئة الخيارات الـ 4 آلياً!",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    Button(
      onClick = {
        editingProduct = null
        resetForm()
        showAddDialog = true
      },
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(10.dp)
    ) {
      Icon(imageVector = Icons.Default.Add, contentDescription = null)
      Spacer(modifier = Modifier.width(6.dp))
      Text("إضافة منتج جديد مع الذكاء الاصطناعي")
    }

    Spacer(modifier = Modifier.height(16.dp))

    Text(
      text = "قائمة المنتجات الحالية في متجرك (${products.size}):",
      fontWeight = FontWeight.Bold,
      fontSize = 15.sp
    )

    Spacer(modifier = Modifier.height(8.dp))

    products.forEach { prod ->
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 6.dp),
        shape = RoundedCornerShape(10.dp)
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(text = prod.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
            Text(text = "السعر: ${prod.price.toInt()} ر.س • ${prod.category}", fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
            Text(text = "الخيارات الـ 4: ${prod.option1Label} | ${prod.option2Label} | ${prod.option3Label} | ${prod.option4Label}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
          }

          Row {
            IconButton(
              onClick = {
                editingProduct = prod
                resetForm(prod)
                showAddDialog = true
              }
            ) {
              Icon(imageVector = Icons.Default.Edit, contentDescription = "تعديل", tint = MaterialTheme.colorScheme.primary)
            }
            IconButton(onClick = { onDeleteProduct(prod.id) }) {
              Icon(imageVector = Icons.Default.Delete, contentDescription = "حذف", tint = MaterialTheme.colorScheme.error)
            }
          }
        }
      }
    }
  }

  // Add / Edit Product Modal with AI
  if (showAddDialog) {
    Dialog(
      onDismissRequest = { showAddDialog = false },
      properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
      Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
      ) {
        Column(
          modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = if (editingProduct == null) "إضافة منتج وتعبئة الخيارات الـ 4" else "تعديل المنتج",
              fontWeight = FontWeight.Bold,
              fontSize = 17.sp
            )
            IconButton(onClick = { showAddDialog = false }) {
              Icon(imageVector = Icons.Default.Close, contentDescription = null)
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // AI Prompt Generator Box
          Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
            shape = RoundedCornerShape(12.dp)
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "كتابة الوصف والخيارات بـ Gemini 3.8 Flash الذكي:",
                  fontWeight = FontWeight.Bold,
                  fontSize = 13.sp,
                  color = MaterialTheme.colorScheme.primary
                )
              }
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = "مدعوم رسمياً بنموذج Google Gemini API عبر Firebase AI Logic",
                fontSize = 10.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
              Spacer(modifier = Modifier.height(6.dp))
              OutlinedTextField(
                value = promptInput,
                onValueChange = { promptInput = it },
                label = { Text("اكتب اسم القطعة (مثال: دبة تلوث ديزل لاندكروزر أو بنزين كامري)") },
                modifier = Modifier.fillMaxWidth()
              )
              Spacer(modifier = Modifier.height(8.dp))
              Button(
                onClick = {
                  if (promptInput.isNotBlank()) {
                    scope.launch {
                      isAiGenerating = true
                      val generated = AiDescriptionGenerator.generateProductDetails(promptInput)
                      formTitle = generated.title
                      formDesc = generated.description
                      formPrice = generated.suggestedPrice.toInt().toString()
                      formOpt1Label = generated.option1Label
                      formOpt1Values = generated.option1Values.joinToString(", ")
                      formOpt2Label = generated.option2Label
                      formOpt2Values = generated.option2Values.joinToString(", ")
                      formOpt3Label = generated.option3Label
                      formOpt3Values = generated.option3Values.joinToString(", ")
                      formOpt4Label = generated.option4Label
                      formOpt4Values = generated.option4Values.joinToString(", ")
                      isAiGenerating = false
                      Toast.makeText(context, "تم توليد وتعبئة الوصف والخيارات بالذكاء الاصطناعي بنجاح!", Toast.LENGTH_SHORT).show()
                    }
                  }
                },
                enabled = !isAiGenerating,
                modifier = Modifier.fillMaxWidth()
              ) {
                if (isAiGenerating) {
                  CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White)
                  Spacer(modifier = Modifier.width(8.dp))
                  Text("جاري الصياغة والتوليد بالذكاء الاصطناعي...")
                } else {
                  Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null)
                  Spacer(modifier = Modifier.width(6.dp))
                  Text("توليد الوصف والخيارات الأربعة الآن")
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          OutlinedTextField(
            value = formTitle,
            onValueChange = { formTitle = it },
            label = { Text("عنوان المنتج") },
            modifier = Modifier.fillMaxWidth()
          )
          Spacer(modifier = Modifier.height(8.dp))

          OutlinedTextField(
            value = formDesc,
            onValueChange = { formDesc = it },
            label = { Text("الوصف التفصيلي للمنتج") },
            minLines = 3,
            modifier = Modifier.fillMaxWidth()
          )
          Spacer(modifier = Modifier.height(8.dp))

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
              value = formPrice,
              onValueChange = { formPrice = it },
              label = { Text("السعر (ر.س)") },
              modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
              value = formCategory,
              onValueChange = { formCategory = it },
              label = { Text("التصنيف") },
              modifier = Modifier.weight(1f)
            )
          }

          Spacer(modifier = Modifier.height(14.dp))
          Text(text = "الخيارات الأربعة المخصصة (يقوم المالك بتعبئتها وتظهر للعميل للاختيار):", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.height(6.dp))

          // Field 1
          OutlinedTextField(value = formOpt1Label, onValueChange = { formOpt1Label = it }, label = { Text("اسم الخيار 1") }, modifier = Modifier.fillMaxWidth())
          OutlinedTextField(value = formOpt1Values, onValueChange = { formOpt1Values = it }, label = { Text("قيم الخيار 1 (افصل بفاصلة)") }, modifier = Modifier.fillMaxWidth())
          Spacer(modifier = Modifier.height(8.dp))

          // Field 2
          OutlinedTextField(value = formOpt2Label, onValueChange = { formOpt2Label = it }, label = { Text("اسم الخيار 2") }, modifier = Modifier.fillMaxWidth())
          OutlinedTextField(value = formOpt2Values, onValueChange = { formOpt2Values = it }, label = { Text("قيم الخيار 2 (افصل بفاصلة)") }, modifier = Modifier.fillMaxWidth())
          Spacer(modifier = Modifier.height(8.dp))

          // Field 3
          OutlinedTextField(value = formOpt3Label, onValueChange = { formOpt3Label = it }, label = { Text("اسم الخيار 3") }, modifier = Modifier.fillMaxWidth())
          OutlinedTextField(value = formOpt3Values, onValueChange = { formOpt3Values = it }, label = { Text("قيم الخيار 3 (افصل بفاصلة)") }, modifier = Modifier.fillMaxWidth())
          Spacer(modifier = Modifier.height(8.dp))

          // Field 4
          OutlinedTextField(value = formOpt4Label, onValueChange = { formOpt4Label = it }, label = { Text("اسم الخيار 4") }, modifier = Modifier.fillMaxWidth())
          OutlinedTextField(value = formOpt4Values, onValueChange = { formOpt4Values = it }, label = { Text("قيم الخيار 4 (افصل بفاصلة)") }, modifier = Modifier.fillMaxWidth())
          Spacer(modifier = Modifier.height(16.dp))

          Button(
            onClick = {
              if (formTitle.isNotBlank()) {
                val p = Product(
                  id = editingProduct?.id ?: "cat-${System.currentTimeMillis() % 10000}",
                  title = formTitle,
                  description = formDesc,
                  price = formPrice.toDoubleOrNull() ?: 1200.0,
                  category = formCategory,
                  option1Label = formOpt1Label,
                  option1Values = formOpt1Values.split(",").map { it.trim() }.filter { it.isNotBlank() },
                  option2Label = formOpt2Label,
                  option2Values = formOpt2Values.split(",").map { it.trim() }.filter { it.isNotBlank() },
                  option3Label = formOpt3Label,
                  option3Values = formOpt3Values.split(",").map { it.trim() }.filter { it.isNotBlank() },
                  option4Label = formOpt4Label,
                  option4Values = formOpt4Values.split(",").map { it.trim() }.filter { it.isNotBlank() },
                  imageDrawableName = editingProduct?.imageDrawableName ?: "prod_cat_converter_1794448832780"
                )
                if (editingProduct == null) onAddProduct(p) else onUpdateProduct(p)
                showAddDialog = false
                Toast.makeText(context, "تم حفظ المنتج بنجاح!", Toast.LENGTH_SHORT).show()
              }
            },
            modifier = Modifier.fillMaxWidth().height(48.dp)
          ) {
            Text("حفظ المنتج في المتجر", fontWeight = FontWeight.Bold)
          }
        }
      }
    }
  }
}

@Composable
private fun ImportByUrlTab(
  onImportUrl: suspend (String) -> Product
) {
  val scope = rememberCoroutineScope()
  val context = LocalContext.current
  var urlInput by remember { mutableStateOf("") }
  var isScraping by remember { mutableStateOf(false) }
  var importedResult by remember { mutableStateOf<Product?>(null) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
      .verticalScroll(rememberScrollState())
  ) {
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(imageVector = Icons.Default.Link, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.width(8.dp))
          Text(text = "سحب المنتجات من أي موقع إلكتروني بالرابط", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = "الصق رابط منتج دبة تلوث أو قطعة عادم من أي موقع خارجي، وسيقوم النظام آلياً باستخراج الصور والعنوان والوصف وتجهيزه لمتجرك:",
          fontSize = 12.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    OutlinedTextField(
      value = urlInput,
      onValueChange = { urlInput = it },
      label = { Text("رابط المنتج (مثال: https://example.com/product/123)") },
      modifier = Modifier.fillMaxWidth()
    )

    Spacer(modifier = Modifier.height(12.dp))

    Button(
      onClick = {
        if (urlInput.isNotBlank()) {
          scope.launch {
            isScraping = true
            try {
              val p = onImportUrl(urlInput.trim())
              importedResult = p
              Toast.makeText(context, "تم سحب المنتج وإضافته لمتجرك بنجاح!", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
              Toast.makeText(context, "حدث خطأ أثناء السحب: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
              isScraping = false
            }
          }
        }
      },
      enabled = !isScraping && urlInput.isNotBlank(),
      modifier = Modifier.fillMaxWidth().height(48.dp)
    ) {
      if (isScraping) {
        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White)
        Spacer(modifier = Modifier.width(8.dp))
        Text("جاري استخراج بيانات المنتج والصور...")
      } else {
        Icon(imageVector = Icons.Default.Download, contentDescription = null)
        Spacer(modifier = Modifier.width(6.dp))
        Text("سحب واستيراد المنتج الآن")
      }
    }

    Spacer(modifier = Modifier.height(18.dp))

    if (importedResult != null) {
      val res = importedResult!!
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Text(text = "✅ تم استيراد المنتج بنجاح:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
          Spacer(modifier = Modifier.height(4.dp))
          Text(text = "العنوان: ${res.title}", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
          Text(text = "السعر المقترح: ${res.price.toInt()} ر.س", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp)
          Text(text = "الخيارات الـ 4 المخصصة مجهزة وجاهزة في المتجر للطلب عبر الواتساب.", fontSize = 11.sp)
        }
      }
    }
  }
}

@Composable
private fun ThemeAndNameTab(
  settings: StoreSettings,
  onUpdateSettings: (StoreSettings) -> Unit
) {
  val context = LocalContext.current
  var storeNameInput by remember(settings) { mutableStateOf(settings.storeName) }
  var whatsappInput by remember(settings) { mutableStateOf(settings.whatsappNumber) }
  var emailInput by remember(settings) { mutableStateOf(settings.storeEmail) }
  var phoneInput by remember(settings) { mutableStateOf(settings.storePhone) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
      .verticalScroll(rememberScrollState())
  ) {
    Text(text = "تعديل اسم المتجر وهوية الألوان (Theme):", fontWeight = FontWeight.Bold, fontSize = 16.sp)
    Spacer(modifier = Modifier.height(12.dp))

    OutlinedTextField(
      value = storeNameInput,
      onValueChange = { storeNameInput = it },
      label = { Text("اسم المتجر الرئيسي") },
      modifier = Modifier.fillMaxWidth()
    )

    Spacer(modifier = Modifier.height(10.dp))

    OutlinedTextField(
      value = whatsappInput,
      onValueChange = { whatsappInput = it },
      label = { Text("رقم الواتساب المعتمد للطلبات (0565911414)") },
      modifier = Modifier.fillMaxWidth()
    )

    Spacer(modifier = Modifier.height(10.dp))

    OutlinedTextField(
      value = emailInput,
      onValueChange = { emailInput = it },
      label = { Text("البريد الإلكتروني للمتجر") },
      modifier = Modifier.fillMaxWidth()
    )

    Spacer(modifier = Modifier.height(16.dp))

    Text(text = "اختيار باليت ألوان الثيم للمتجر:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
    Spacer(modifier = Modifier.height(8.dp))

    StoreThemePalette.values().forEach { palette ->
      val isSelected = settings.activeTheme == palette.name
      Surface(
        modifier = Modifier
          .fillMaxWidth()
          .padding(vertical = 4.dp)
          .border(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.3f),
            shape = RoundedCornerShape(10.dp)
          )
          .clickable {
            onUpdateSettings(settings.copy(activeTheme = palette.name))
          },
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surface
      ) {
        Row(
          modifier = Modifier.padding(12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(24.dp)
              .clip(CircleShape)
              .background(Color(android.graphics.Color.parseColor(palette.primaryHex)))
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(text = palette.labelArabic, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal, fontSize = 14.sp)
          if (isSelected) {
            Spacer(modifier = Modifier.weight(1f))
            Text(text = "مفعل حالياً ✓", color = MaterialTheme.colorScheme.primary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))

    Button(
      onClick = {
        onUpdateSettings(
          settings.copy(
            storeName = storeNameInput,
            whatsappNumber = whatsappInput,
            storeEmail = emailInput,
            storePhone = phoneInput
          )
        )
        Toast.makeText(context, "تم حفظ وتحديث إعدادات واسم المتجر بنجاح", Toast.LENGTH_SHORT).show()
      },
      modifier = Modifier.fillMaxWidth().height(48.dp)
    ) {
      Text("حفظ التغييرات الآن")
    }
  }
}

@Composable
private fun MarqueeAndVideoTab(
  settings: StoreSettings,
  onUpdateSettings: (StoreSettings) -> Unit
) {
  val context = LocalContext.current
  var marqueeTextInput by remember(settings) { mutableStateOf(settings.marqueeText) }
  var selectedSpeed by remember(settings) { mutableStateOf(settings.marqueeSpeed) }
  var marqueeBgInput by remember(settings) { mutableStateOf(settings.marqueeBgColorHex) }

  var headerTitleInput by remember(settings) { mutableStateOf(settings.headerVideoTitle) }
  var headerDescInput by remember(settings) { mutableStateOf(settings.headerVideoDesc) }
  var footerTitleInput by remember(settings) { mutableStateOf(settings.footerVideoTitle) }
  var footerDescInput by remember(settings) { mutableStateOf(settings.footerVideoDesc) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
      .verticalScroll(rememberScrollState())
  ) {
    Text(text = "إعدادات الشريط الإعلاني المتحرك (Top Marquee):", fontWeight = FontWeight.Bold, fontSize = 15.sp)
    Spacer(modifier = Modifier.height(8.dp))

    OutlinedTextField(
      value = marqueeTextInput,
      onValueChange = { marqueeTextInput = it },
      label = { Text("نص الإعلان في الشريط المتحرك") },
      minLines = 2,
      modifier = Modifier.fillMaxWidth()
    )

    Spacer(modifier = Modifier.height(10.dp))

    Text(text = "سرعة حركة الشريط (مرن وقوالب للسرعات):", fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 6.dp)) {
      MarqueeSpeed.values().forEach { speed ->
        Button(
          onClick = { selectedSpeed = speed },
          colors = ButtonDefaults.buttonColors(
            containerColor = if (selectedSpeed == speed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
          ),
          shape = RoundedCornerShape(8.dp)
        ) {
          Text(text = speed.labelArabic, color = if (selectedSpeed == speed) Color.Black else MaterialTheme.colorScheme.onSurface)
        }
      }
    }

    Spacer(modifier = Modifier.height(16.dp))
    HorizontalDivider()
    Spacer(modifier = Modifier.height(16.dp))

    Text(text = "مقاطع فيديو رأس وأسفل الصفحة (Header & Footer Videos):", fontWeight = FontWeight.Bold, fontSize = 15.sp)
    Spacer(modifier = Modifier.height(8.dp))

    OutlinedTextField(
      value = headerTitleInput,
      onValueChange = { headerTitleInput = it },
      label = { Text("عنوان فيديو رأس الصفحة (الهيدر)") },
      modifier = Modifier.fillMaxWidth()
    )
    Spacer(modifier = Modifier.height(6.dp))
    OutlinedTextField(
      value = headerDescInput,
      onValueChange = { headerDescInput = it },
      label = { Text("وصف فيديو الهيدر") },
      modifier = Modifier.fillMaxWidth()
    )

    Spacer(modifier = Modifier.height(10.dp))

    OutlinedTextField(
      value = footerTitleInput,
      onValueChange = { footerTitleInput = it },
      label = { Text("عنوان فيديو أسفل الصفحة (تجارب العملاء)") },
      modifier = Modifier.fillMaxWidth()
    )
    Spacer(modifier = Modifier.height(6.dp))
    OutlinedTextField(
      value = footerDescInput,
      onValueChange = { footerDescInput = it },
      label = { Text("وصف فيديو الفوتر") },
      modifier = Modifier.fillMaxWidth()
    )

    Spacer(modifier = Modifier.height(16.dp))

    Button(
      onClick = {
        onUpdateSettings(
          settings.copy(
            marqueeText = marqueeTextInput,
            marqueeSpeed = selectedSpeed,
            marqueeBgColorHex = marqueeBgInput,
            headerVideoTitle = headerTitleInput,
            headerVideoDesc = headerDescInput,
            footerVideoTitle = footerTitleInput,
            footerVideoDesc = footerDescInput
          )
        )
        Toast.makeText(context, "تم حفظ إعدادات الشريط المتحرك والفيديوهات بنجاح", Toast.LENGTH_SHORT).show()
      },
      modifier = Modifier.fillMaxWidth().height(48.dp)
    ) {
      Text("حفظ التحديثات الآن")
    }
  }
}

@Composable
private fun GoogleSeoAndApkTab(
  products: List<Product>,
  settings: StoreSettings
) {
  val context = LocalContext.current

  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
      .verticalScroll(rememberScrollState())
  ) {
    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.width(8.dp))
          Text(text = "ظهور المنتجات في بحث جوجل (Google SEO)", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = "تم تجهيز جميع منتجاتك بمخطط Schema.org المعتمد من محرك بحث جوجل (Rich Snippets). ستظهر منتجاتك تلقائياً مع السعر، النجوم، التقييم، وتوافر المخزون.",
          fontSize = 12.sp,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
      }
    }

    Spacer(modifier = Modifier.height(14.dp))

    Text(text = "محاكاة شكل منتجك في بحث جوجل على الجوال:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
    Spacer(modifier = Modifier.height(8.dp))

    val firstProd = products.firstOrNull()
    if (firstProd != null) {
      // Google search result card simulation
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
      ) {
        Column(modifier = Modifier.padding(12.dp)) {
          Text(text = "dabat-altalawuth.sa › products › ${firstProd.id}", color = Color(0xFF4D5156), fontSize = 11.sp)
          Spacer(modifier = Modifier.height(2.dp))
          Text(text = "${firstProd.title} - متجر دبات التلوث الأصلي", color = Color(0xFF1A0DAB), fontSize = 15.sp, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(4.dp))
          Text(text = "⭐⭐⭐⭐⭐ تقييم: ${firstProd.rating} • السعر: ${firstProd.price.toInt()} ر.س • متوفر في المخزن • اطلب عبر الواتساب 0565911414", color = Color(0xFF4D5156), fontSize = 12.sp)
        }
      }
    }

    Spacer(modifier = Modifier.height(20.dp))
    HorizontalDivider()
    Spacer(modifier = Modifier.height(16.dp))

    // APK Download instructions
    Row(verticalAlignment = Alignment.CenterVertically) {
      Icon(imageVector = Icons.Default.Download, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
      Spacer(modifier = Modifier.width(8.dp))
      Text(text = "تنزيل التطبيق وتثبيته على جهازك الخاص:", fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }

    Spacer(modifier = Modifier.height(8.dp))

    Card(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
      Column(modifier = Modifier.padding(14.dp)) {
        Text(
          text = "📲 خطوات تثبيت التطبيق على جوالك الأندرويد:",
          fontWeight = FontWeight.Bold,
          fontSize = 13.sp,
          color = MaterialTheme.colorScheme.onPrimaryContainer
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = """
1. افتح قائمة الإعدادات أو زر المشاركة/البناء في منصة AI Studio.
2. اضغط على خيار "Export APK" أو "تصدير حزمة الأندرويد".
3. سيتم تنزيل ملف التثبيت بصيغة APK على جوالك مباشرة.
4. اضغط على الملف ووافق على التثبيت ليظهر تطبيق متجرك "دبات التلوث" على الشاشة الرئيسية لجوالك بأيقونته الفاخرة المعتمدة.
          """.trimIndent(),
          fontSize = 12.sp,
          lineHeight = 20.sp,
          color = MaterialTheme.colorScheme.onPrimaryContainer
        )
      }
    }
  }
}

@Composable
private fun ComplaintsTab(complaints: List<Complaint>) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(16.dp)
      .verticalScroll(rememberScrollState())
  ) {
    Text(text = "صندوق رسائل وشكاوى واقتراحات العملاء (${complaints.size}):", fontWeight = FontWeight.Bold, fontSize = 16.sp)
    Spacer(modifier = Modifier.height(10.dp))

    if (complaints.isEmpty()) {
      Text(text = "لا توجد رسائل واردة حالياً.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    } else {
      complaints.forEach { c ->
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
          shape = RoundedCornerShape(10.dp)
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(text = "${c.customerName} (${c.type})", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
              Text(text = c.customerContact, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = c.content, fontSize = 13.sp, lineHeight = 19.sp)
          }
        }
      }
    }
  }
}
