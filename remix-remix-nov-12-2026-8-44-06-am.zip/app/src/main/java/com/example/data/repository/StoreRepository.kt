package com.example.data.repository

import android.content.Context
import com.example.data.model.Complaint
import com.example.data.model.CustomerUser
import com.example.data.model.MarqueeSpeed
import com.example.data.model.Product
import com.example.data.model.StoreSettings
import com.example.service.AiDescriptionGenerator
import com.example.service.UrlProductScraper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class StoreRepository private constructor(private val context: Context) {

  companion object {
    @Volatile
    private var INSTANCE: StoreRepository? = null

    fun getInstance(context: Context): StoreRepository {
      return INSTANCE ?: synchronized(this) {
        val instance = StoreRepository(context.applicationContext)
        INSTANCE = instance
        instance
      }
    }
  }

  // Initial products specialized in Catalytic Converters & DPF for Diesel and Petrol
  private val _products = MutableStateFlow<List<Product>>(
    listOf(
      Product(
        id = "cat-001",
        title = "دبة تلوث بنزين سيراميك أصلية يورو 5 (Euro 5 Catalytic Converter)",
        description = """
دبة رصاص وبيئة مطابقة للمواصفات القياسية الأوروبية Euro 5 للسيارات العاملة بالبنزين.
تقضي تماماً على رائحة الكربون الكريهة وتطفي لمبة المكينة (Check Engine P0420 / P0430).
مصنوعة من غلاف ستانلس ستيل معالج مع خلية سيراميك داخلية عالية الكثافة مغطاة بطبقات من البلاتينيوم والبلاديوم لتنقية الغازات واجتياز الفحص الدوري بنجاح 100%.
        """.trimIndent(),
        price = 1450.0,
        originalPrice = 1850.0,
        category = "دبات بنزين",
        rating = 4.9,
        reviewCount = 64,
        imageDrawableName = "prod_cat_converter_1794448832780",
        option1Label = "نوع الوقود والمحرك",
        option1Values = listOf("بنزين Petrol 4 سلندر", "بنزين Petrol 6 و 8 سلندر"),
        option2Label = "كثافة ونوع الخلية الداخلية",
        option2Values = listOf("سيراميك أصلي وكالة (High Filtration)", "معدن رياضي 300 Cell"),
        option3Label = "مقاس القطر ومدخل الماسورة",
        option3Values = listOf("2.0 بوصة قياسي", "2.5 بوصة واسع", "3.0 بوصة رياضي"),
        option4Label = "سنة الصنع وتوافق الفحص الدوري",
        option4Values = listOf("تطفي لمبة المكينة وتجتاز الفحص 100%", "مع فتحة حساس أكسجين O2 جاهزة")
      ),
      Product(
        id = "dpf-002",
        title = "فلتر ودبة تلوث ديزل DPF معالجة كاملة للشاحنات والجيوب",
        description = """
فلتر التقاط جزيئات الديزل (Diesel Particulate Filter DPF) شديد التحمل للشاحنات والسيارات الديزل (تويوتا هايلوكس، فورتشنر، لاندكروزر، ميتسوبيشي، إيسوزو، فورد).
يمنع خروج الدخان الأسود ويحسن كفاءة حرق الوقود واستجابة التيربو ويحتوي على أنابيب حساسات فرق الضغط الأصلية.
        """.trimIndent(),
        price = 2200.0,
        originalPrice = 2750.0,
        category = "دبات ديزل",
        rating = 5.0,
        reviewCount = 42,
        imageDrawableName = "prod_dpf_diesel_1794448831848",
        option1Label = "نوع المحرك والديزل",
        option1Values = listOf("تيربو ديزل Common Rail (حديث)", "ديزل تقليدي Heavy Duty"),
        option2Label = "سعة الفلتر ومعالجة الرماد",
        option2Values = listOf("فلتر DPF سيليكون كاربايد (SiC)", "فلتر معالج كوديريت Cordierite"),
        option3Label = "مقاس الشفاه ومسار العادم",
        option3Values = listOf("فلنجة وكالة جاهزة (Direct Fit)", "توصيل لحام يونيفرسال"),
        option4Label = "توافق الموديل",
        option4Values = listOf("موديلات 2018 - 2025", "موديلات 2012 - 2017")
      ),
      Product(
        id = "sport-003",
        title = "دبة تلوث معدنية رياضية هاي فلو 200 خلية (200 CPSI Metal Cat)",
        description = """
دبة بيئة معدنية رياضية تدفق عالي High-Flow مصنوعة من صفائح الفولاذ المقاوم للصدأ المطلية بمادة الروديوم.
تتيح تنقية عوادم البنزين والديزل الرياضي مع تقليل ضغط الارتداد العكسي (Backpressure) لزيادة عزم الدوران وقوة الأحصنة مع المحافظة على البيئة واجتياز فحص الانبعاثات.
        """.trimIndent(),
        price = 1680.0,
        originalPrice = 1990.0,
        category = "دبات رياضية",
        rating = 4.8,
        reviewCount = 51,
        imageDrawableName = "prod_exhaust_quad_1794448543230",
        option1Label = "نوع الوقود المدعوم",
        option1Values = listOf("بنزين سوبر/رياضي", "ديزل رياضي مع تيربو معدل"),
        option2Label = "كثافة الخلية الرياضية",
        option2Values = listOf("200 CPSI (أقصى تدفق وقوة)", "300 CPSI (توازن بين القوة والتنقية)"),
        option3Label = "قطر الأنبوب والتركيب",
        option3Values = listOf("2.5 بوصة (In/Out)", "3.0 بوصة (In/Out)"),
        option4Label = "طريقة التثبيت",
        option4Values = listOf("لحام مباشر مع سناتر حساس O2", "كلبسات فك وتركيب سريعة V-Band")
      ),
      Product(
        id = "ecu-004",
        title = "جهاز فحص وبرمجة حساسات دبات التلوث ومسح أكواد P0420",
        description = """
جهاز إلكتروني ذكي للمحافظة على أداء دبات التلوث في محركات الديزل والبنزين، يقرأ كفاءة المحفز الحفاز، ضغط فلتر الـ DPF، حرارة غازات العادم EGT، ومسح الأخطاء.
        """.trimIndent(),
        price = 850.0,
        originalPrice = 1100.0,
        category = "إلكترونيات وفحص",
        rating = 4.7,
        reviewCount = 29,
        imageDrawableName = "prod_tuning_ecu_1794448742439",
        option1Label = "نوع الفحص المطلوب",
        option1Values = listOf("فحص دبات بنزين (O2 Sensors)", "فحص فلاتر ديزل وتجديد DPF Regen"),
        option2Label = "نوع الاتصال",
        option2Values = listOf("شاشة مستقلة + كابل OBD2", "ربط بلوتوث وتطبيق جوال"),
        option3Label = "اللغة والبرمجة",
        option3Values = listOf("لغة عربية كاملة + إنجليزي", "تحديثات مجانية مدى الحياة"),
        option4Label = "الضمان",
        option4Values = listOf("ضمان استبدال لمدة سنتين", "دعم فني عبر واتساب 0565911414")
      )
    )
  )
  val products: StateFlow<List<Product>> = _products.asStateFlow()

  private val _storeSettings = MutableStateFlow(
    StoreSettings(
      storeName = "دبات التلوث في الديزل والبنزين",
      marqueeText = "🌟 مرحباً بكم في متجر دبات التلوث وفلاتر الديزل والبنزين الأصلية | ضمان اجتياز الفحص الدوري وإطفاء لمبة المكينة | الطلب والشحن لجميع مناطق المملكة عبر الواتساب: 0565911414",
      marqueeSpeed = MarqueeSpeed.MEDIUM,
      headerVideoTitle = "شرح عمل دبة التلوث وفلتر الديزل DPF وكيف تحمي سيارتك من الأعطال",
      headerVideoDesc = "فيديو توضيحي لطريقة تنقية انبعاثات الكربون واجتياز الفحص الفني بكل سهولة",
      footerVideoTitle = "تجارب عملائنا بعد تركيب دبات التلوث الأصلية واختبار الفحص الدوري",
      footerVideoDesc = "شاهد اختفاء الدخان الأسود وانطفاء لمبة المحرك بعد التركيب المباشر",
      whatsappNumber = "0565911414",
      storeEmail = "dbattloth.221@gmail.com",
      storePhone = "0565911414"
    )
  )
  val storeSettings: StateFlow<StoreSettings> = _storeSettings.asStateFlow()

  private val _complaints = MutableStateFlow<List<Complaint>>(
    listOf(
      Complaint(
        id = "c-101",
        customerName = "أبو فهد العتيبي",
        customerContact = "0501234567",
        type = "اقتراح",
        content = "يا ريت توفرون مقاسات دبات تلوث خاصة للشاحنات الكبيرة تريلات مرسيدس وفولفو ديزل.",
        timestamp = System.currentTimeMillis() - 86400000L
      )
    )
  )
  val complaints: StateFlow<List<Complaint>> = _complaints.asStateFlow()

  private val _currentUser = MutableStateFlow(CustomerUser())
  val currentUser: StateFlow<CustomerUser> = _currentUser.asStateFlow()

  // User Authentication
  fun loginCustomer(contact: String, name: String = "عميل مميز") {
    val isOwner = contact.trim() == "0565911414" || contact.trim() == "565911414" || contact.trim() == "admin"
    _currentUser.value = CustomerUser(
      contactInfo = contact,
      displayName = if (isOwner) "مالك المتجر (المدير)" else name,
      isOwner = isOwner,
      isLoggedIn = true
    )
  }

  fun loginOwner() {
    _currentUser.value = CustomerUser(
      contactInfo = "0565911414",
      displayName = "مالك المتجر (المدير)",
      isOwner = true,
      isLoggedIn = true
    )
  }

  fun logout() {
    _currentUser.value = CustomerUser()
  }

  // Store Settings Customization (Name, Colors, Videos, Marquee, Policies)
  fun updateStoreSettings(newSettings: StoreSettings) {
    _storeSettings.value = newSettings
  }

  fun updateStoreName(newName: String) {
    _storeSettings.update { it.copy(storeName = newName) }
  }

  fun updateTheme(paletteName: String) {
    _storeSettings.update { it.copy(activeTheme = paletteName) }
  }

  fun updateMarquee(text: String, speed: MarqueeSpeed, bgColor: String) {
    _storeSettings.update {
      it.copy(
        marqueeText = text,
        marqueeSpeed = speed,
        marqueeBgColorHex = bgColor
      )
    }
  }

  fun updateVideos(headerTitle: String, headerDesc: String, footerTitle: String, footerDesc: String) {
    _storeSettings.update {
      it.copy(
        headerVideoTitle = headerTitle,
        headerVideoDesc = headerDesc,
        footerVideoTitle = footerTitle,
        footerVideoDesc = footerDesc
      )
    }
  }

  // Product Management
  fun addProduct(product: Product) {
    _products.update { listOf(product) + it }
  }

  fun updateProduct(product: Product) {
    _products.update { current ->
      current.map { if (it.id == product.id) product else it }
    }
  }

  fun deleteProduct(productId: String) {
    _products.update { current ->
      current.filterNot { it.id == productId }
    }
  }

  // Scrape and import product via URL
  suspend fun importProductFromUrl(url: String): Product {
    val scraped = UrlProductScraper.scrapeUrl(url)
    // Run AI to optimize Arabic copywriting and the 4 options:
    val aiDetails = AiDescriptionGenerator.generateProductDetails(
      inputPrompt = scraped.title,
      categoryHint = "دبات التلوث"
    )

    val newProduct = Product(
      id = "imp-${System.currentTimeMillis() % 10000}",
      title = if (scraped.title.isNotBlank()) scraped.title else aiDetails.title,
      description = if (scraped.description.isNotBlank()) "${scraped.description}\n\n${aiDetails.description}" else aiDetails.description,
      price = scraped.price ?: aiDetails.suggestedPrice,
      originalPrice = (scraped.price ?: aiDetails.suggestedPrice) * 1.25,
      category = "مستورد بالرابط",
      rating = 4.9,
      reviewCount = 12,
      imageDrawableName = "prod_cat_converter_1794448832780",
      customImageUrl = scraped.imageUrl,
      option1Label = aiDetails.option1Label,
      option1Values = aiDetails.option1Values,
      option2Label = aiDetails.option2Label,
      option2Values = aiDetails.option2Values,
      option3Label = aiDetails.option3Label,
      option3Values = aiDetails.option3Values,
      option4Label = aiDetails.option4Label,
      option4Values = aiDetails.option4Values,
      importedFromUrl = url
    )

    addProduct(newProduct)
    return newProduct
  }

  // Complaints / Suggestions
  fun submitComplaint(name: String, contact: String, type: String, content: String) {
    val item = Complaint(
      id = "c-${System.currentTimeMillis() % 10000}",
      customerName = name,
      customerContact = contact,
      type = type,
      content = content,
      timestamp = System.currentTimeMillis()
    )
    _complaints.update { listOf(item) + it }
  }
}
