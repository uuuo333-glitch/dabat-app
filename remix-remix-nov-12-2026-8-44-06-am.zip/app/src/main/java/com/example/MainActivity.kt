package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Product
import com.example.data.repository.StoreRepository
import com.example.ui.components.CustomerAuthDialog
import com.example.ui.components.FooterSection
import com.example.ui.components.MarqueeAnnouncementBar
import com.example.ui.components.OwnerAdminPortal
import com.example.ui.components.ProductCard
import com.example.ui.components.ProductDetailDialog
import com.example.ui.components.VideoBannerCard
import com.example.ui.theme.SmartStoreTheme
import com.example.ui.theme.StoreThemePalette
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    com.example.util.configureAppCheck(this, intent)
    enableEdgeToEdge()

    val repository = StoreRepository.getInstance(applicationContext)

    setContent {
      val settings by repository.storeSettings.collectAsState()
      val products by repository.products.collectAsState()
      val complaints by repository.complaints.collectAsState()
      val currentUser by repository.currentUser.collectAsState()

      val activePalette = remember(settings.activeTheme) {
        try {
          StoreThemePalette.valueOf(settings.activeTheme)
        } catch (_: Exception) {
          StoreThemePalette.GOLD
        }
      }

      SmartStoreTheme(themePalette = activePalette) {
        // Enforce RTL direction for Arabic store
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
          StoreMainScreen(
            repository = repository,
            settings = settings,
            products = products,
            complaints = complaints,
            currentUser = currentUser
          )
        }
      }
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StoreMainScreen(
  repository: StoreRepository,
  settings: com.example.data.model.StoreSettings,
  products: List<Product>,
  complaints: List<com.example.data.model.Complaint>,
  currentUser: com.example.data.model.CustomerUser
) {
  val scope = rememberCoroutineScope()

  var selectedProductForDetail by remember { mutableStateOf<Product?>(null) }
  var showOwnerPortal by remember { mutableStateOf(false) }
  var showCustomerAuth by remember { mutableStateOf(false) }

  var searchQuery by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf("الكل") }

  // Filtered products list
  val filteredProducts = remember(products, searchQuery, selectedCategory) {
    products.filter { prod ->
      val matchesCategory = selectedCategory == "الكل" || prod.category.contains(selectedCategory) || (selectedCategory == "ديزل" && prod.title.contains("ديزل")) || (selectedCategory == "بنزين" && prod.title.contains("بنزين"))
      val matchesSearch = searchQuery.isBlank() || prod.title.contains(searchQuery, ignoreCase = true) || prod.description.contains(searchQuery, ignoreCase = true)
      matchesCategory && matchesSearch
    }
  }

  val categories = listOf("الكل", "دبات بنزين", "دبات ديزل", "دبات رياضية", "إلكترونيات وفحص")

  Scaffold(
    modifier = Modifier
      .fillMaxSize()
      .statusBarsPadding()
      .navigationBarsPadding()
      .testTag("store_main_screen"),
    topBar = {
      Column {
        // 1. Dynamic Moving Marquee Announcement Bar with speed control
        MarqueeAnnouncementBar(
          text = settings.marqueeText,
          speed = settings.marqueeSpeed,
          bgColorHex = settings.marqueeBgColorHex
        )

        // 2. Main Store Top Bar
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(horizontal = 16.dp, vertical = 12.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.ShoppingBag,
                contentDescription = "شعار المتجر",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = settings.storeName,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1
              )
              Text(
                text = "الطلب المباشر عبر واتساب: ${settings.whatsappNumber}",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.SemiBold
              )
            }
          }

          // User / Owner Actions
          Row(verticalAlignment = Alignment.CenterVertically) {
            // Customer Login button
            IconButton(
              onClick = { showCustomerAuth = true },
              modifier = Modifier
                .size(36.dp)
                .background(MaterialTheme.colorScheme.surfaceVariant, CircleShape)
            ) {
              Icon(
                imageVector = Icons.Default.AccountCircle,
                contentDescription = "دخول العميل",
                tint = if (currentUser.isLoggedIn) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(20.dp)
              )
            }

            Spacer(modifier = Modifier.width(6.dp))

            // Owner Portal Access
            IconButton(
              onClick = { showOwnerPortal = true },
              modifier = Modifier
                .size(36.dp)
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f), CircleShape)
                .testTag("admin_icon_button")
            ) {
              Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "لوحة المالك والذكاء الاصطناعي",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
              )
            }
          }
        }
      }
    }
  ) { innerPadding ->
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding),
      contentPadding = PaddingValues(bottom = 24.dp)
    ) {
      // Header Video Section
      item {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
          VideoBannerCard(
            title = settings.headerVideoTitle,
            description = settings.headerVideoDesc,
            badgeText = "فيديو توضيحي لرأس الصفحة",
            placeholderDrawableName = "hero_store_banner_1794448546017",
            testTag = "header_video_card"
          )
        }
      }

      // Search & Filters Section
      item {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) {
          // Search Box
          OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("ابحث عن دبة تلوث أو فلتر ديزل أو نوع سيارتك...") },
            leadingIcon = {
              Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            },
            trailingIcon = {
              if (searchQuery.isNotEmpty()) {
                IconButton(onClick = { searchQuery = "" }) {
                  Icon(imageVector = Icons.Default.Close, contentDescription = "مسح")
                }
              }
            },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
          )

          Spacer(modifier = Modifier.height(10.dp))

          // Category Chips Flow
          FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            categories.forEach { cat ->
              val isSelected = selectedCategory == cat
              Surface(
                shape = RoundedCornerShape(20.dp),
                color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.clickable { selectedCategory = cat }
              ) {
                Text(
                  text = cat,
                  color = if (isSelected) Color.Black else MaterialTheme.colorScheme.onSurface,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                  fontSize = 12.sp,
                  modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Section title for customer focus
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "المنتجات المتوفرة للطلب الفوري (${filteredProducts.size})",
              fontWeight = FontWeight.ExtraBold,
              fontSize = 17.sp,
              color = MaterialTheme.colorScheme.onSurface
            )
            Text(
              text = "اختر المواصفات واطلب عبر الواتساب",
              fontSize = 11.sp,
              color = MaterialTheme.colorScheme.primary
            )
          }
        }
      }

      // Products List Items
      if (filteredProducts.isEmpty()) {
        item {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(40.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = "لا توجد نتائج تطابق بحثك حالياً.",
              color = MaterialTheme.colorScheme.onSurfaceVariant,
              fontSize = 14.sp
            )
          }
        }
      } else {
        items(filteredProducts, key = { it.id }) { product ->
          Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            ProductCard(
              product = product,
              onClick = { selectedProductForDetail = product }
            )
          }
        }
      }

      // Footer Video Section (Customer Reviews / Dyno Sound test)
      item {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 18.dp)) {
          Text(
            text = "فيديو أسفل الصفحة (تجارب الفحص والتركيب):",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(bottom = 8.dp)
          )
          VideoBannerCard(
            title = settings.footerVideoTitle,
            description = settings.footerVideoDesc,
            badgeText = "تجارب حقيقية واختبار الفحص",
            placeholderDrawableName = "hero_store_banner_1794448546017",
            testTag = "footer_video_card"
          )
        }
      }

      // Complete Footer (Socials, About us, Complaints, Policies, Email)
      item {
        FooterSection(
          settings = settings,
          onOpenOwnerPortal = { showOwnerPortal = true },
          onSubmitComplaint = { name, contact, type, content ->
            repository.submitComplaint(name, contact, type, content)
          }
        )
      }
    }
  }

  // Product Detail & 4 Options WhatsApp Order Dialog
  if (selectedProductForDetail != null) {
    ProductDetailDialog(
      product = selectedProductForDetail!!,
      whatsappNumber = settings.whatsappNumber,
      customerName = currentUser.displayName,
      customerContact = currentUser.contactInfo,
      onDismiss = { selectedProductForDetail = null }
    )
  }

  // Customer Login Dialog
  if (showCustomerAuth) {
    CustomerAuthDialog(
      onLogin = { contact, name ->
        repository.loginCustomer(contact, name)
      },
      onDismiss = { showCustomerAuth = false }
    )
  }

  // Owner Admin & AI Suite Dialog
  if (showOwnerPortal) {
    OwnerAdminPortal(
      isOwnerLoggedIn = currentUser.isOwner,
      settings = settings,
      products = products,
      complaints = complaints,
      onLoginOwner = { repository.loginOwner() },
      onLogout = { repository.logout() },
      onUpdateSettings = { repository.updateStoreSettings(it) },
      onAddProduct = { repository.addProduct(it) },
      onUpdateProduct = { repository.updateProduct(it) },
      onDeleteProduct = { repository.deleteProduct(it) },
      onImportUrl = { url -> repository.importProductFromUrl(url) },
      onDismiss = { showOwnerPortal = false }
    )
  }
}
